package zmaster587.advancedRocketry.integration.jei.centrifuge;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class CentrifugeWrapper extends MachineRecipe {

	CentrifugeWrapper(IRecipe rec) {
		super(rec);
	}

}

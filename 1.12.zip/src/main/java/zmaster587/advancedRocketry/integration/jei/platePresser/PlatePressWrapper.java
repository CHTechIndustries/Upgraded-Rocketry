package zmaster587.advancedRocketry.integration.jei.platePresser;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class PlatePressWrapper extends MachineRecipe {

	PlatePressWrapper(IRecipe rec) {
		super(rec);
	}

}

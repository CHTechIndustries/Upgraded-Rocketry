package zmaster587.advancedRocketry.integration.jei.arcFurnace;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class ArcFurnaceWrapper extends MachineRecipe {

	ArcFurnaceWrapper(IRecipe rec) {
		super(rec);
	}

}

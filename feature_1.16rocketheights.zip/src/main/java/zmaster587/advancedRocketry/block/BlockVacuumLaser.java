package zmaster587.advancedRocketry.block;

import net.minecraft.block.material.Material;
import zmaster587.libVulpes.block.BlockFullyRotatable;

public class BlockVacuumLaser extends BlockFullyRotatable {

	public BlockVacuumLaser(Material material) {
		super(material);
	}

}

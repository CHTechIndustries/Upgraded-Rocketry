package zmaster587.advancedRocketry.integration.jei.precisionLaserEtcher;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class PrecisionLaserEtcherWrapper extends MachineRecipe {

	PrecisionLaserEtcherWrapper(IRecipe rec) {
		super(rec);
	}

}

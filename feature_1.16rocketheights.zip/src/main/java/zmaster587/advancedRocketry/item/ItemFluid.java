package zmaster587.advancedRocketry.item;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item.Properties;

public class ItemFluid extends BlockItem {

	public ItemFluid(Properties props, Block block) {
		super(block, props);
	}
	
}

package zmaster587.advancedRocketry.block;

import net.minecraft.block.material.Material;
import net.minecraftforge.fluids.Fluid;

public class BlockEnrichedLava extends BlockFluid {

	public BlockEnrichedLava(Fluid fluid, Material material) {
		super(fluid, material);
	}
	
	//TODO: add eyecandy

}

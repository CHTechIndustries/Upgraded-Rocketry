package zmaster587.advancedRocketry.api;

public class Constants {
	public static final String modId = "advancedrocketry";
	public static final int INVALID_PLANET = Integer.MIN_VALUE + 1; //min value is used for warp
	public static final int GENTYPE_ASTEROID = 2;
	public static final int STAR_ID_OFFSET = 10000;
}

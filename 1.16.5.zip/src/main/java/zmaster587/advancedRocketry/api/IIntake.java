package zmaster587.advancedRocketry.api;

import net.minecraft.block.BlockState;

public interface IIntake {
	int getIntakeAmt(BlockState state);
}

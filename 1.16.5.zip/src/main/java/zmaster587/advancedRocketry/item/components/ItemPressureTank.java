package zmaster587.advancedRocketry.item.components;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.fluids.FluidStack;
import zmaster587.advancedRocketry.api.ARConfiguration;
import zmaster587.advancedRocketry.capability.TankCapabilityItemStack;
import zmaster587.libVulpes.api.IArmorComponent;
import zmaster587.libVulpes.client.ResourceIcon;
import zmaster587.libVulpes.util.FluidUtils;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import java.util.List;

import com.mojang.blaze3d.matrix.MatrixStack;

public class ItemPressureTank extends Item implements IArmorComponent {

	ResourceIcon icon;

	int capacity;
	public ItemPressureTank(Properties props, int capacity) {
		super(props);
		this.capacity = capacity;
	}
	
	@Override
	@ParametersAreNonnullByDefault
	public void addInformation(@Nonnull ItemStack stack, @Nullable World world, List<ITextComponent> list, ITooltipFlag bool) {
		super.addInformation(stack, world, list, bool);
		
		FluidStack fluidStack = FluidUtils.getFluidForItem(stack);
		
		if(fluidStack.isEmpty()) {
			list.add(new TranslationTextComponent("msg.empty"));
		}
		else {
			list.add(new StringTextComponent(fluidStack.getDisplayName().getString() + ": " + fluidStack.getAmount()));
		}
	}
	
	@Override
	public void onTick(World world, PlayerEntity player, ItemStack armorStack, IInventory inv,
			ItemStack componentStack) {
		
	}

	@Override
	public boolean onComponentAdded(World world, @Nonnull ItemStack armorStack) {
		return true;
	}

	@Override
	public void onComponentRemoved(World world, @Nonnull ItemStack armorStack) {
		
	}

	@Override
	public void onArmorDamaged(LivingEntity entity, ItemStack armorStack,
			ItemStack componentStack, DamageSource source, int damage) {
		
	}
	
	public int getCapacity(ItemStack container) {
		return (int)(capacity * ARConfiguration.getCurrentConfig().suitTankCapacity.get());
	}

	@Override
	public ResourceIcon getComponentIcon(@Nonnull ItemStack armorStack) {
		return null;
	}
	
	@Override
	public boolean isAllowedInSlot(ItemStack stack, EquipmentSlotType slot) {
		return slot == EquipmentSlotType.CHEST;
	}

	@Override
	public ICapabilityProvider initCapabilities(ItemStack stack,
			CompoundNBT nbt) {
		return new TankCapabilityItemStack(stack, getCapacity(stack));
	}

	@Override
	public void renderScreen(MatrixStack mat, ItemStack componentStack, List<ItemStack> modules, RenderGameOverlayEvent event,
			Screen gui) {

	}

}

package zmaster587.advancedRocketry.world;

import java.util.OptionalLong;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.DimensionType;
import net.minecraft.world.biome.IBiomeMagnifier;

public class ModdedDimensionType extends DimensionType {

	public ModdedDimensionType(OptionalLong p_i241973_1_, boolean p_i241973_2_, boolean p_i241973_3_,
			boolean p_i241973_4_, boolean p_i241973_5_, double p_i241973_6_, boolean p_i241973_8_, boolean p_i241973_9_,
			boolean p_i241973_10_, boolean p_i241973_11_, boolean p_i241973_12_, int p_i241973_13_,
			IBiomeMagnifier p_i241973_14_, ResourceLocation p_i241973_15_, ResourceLocation p_i241973_16_,
			float p_i241973_17_) {
		super(p_i241973_1_, p_i241973_2_, p_i241973_3_, p_i241973_4_, p_i241973_5_, p_i241973_6_, p_i241973_8_, p_i241973_9_,
				p_i241973_10_, p_i241973_11_, p_i241973_12_, p_i241973_13_, p_i241973_14_, p_i241973_15_, p_i241973_16_,
				p_i241973_17_);
	}

}

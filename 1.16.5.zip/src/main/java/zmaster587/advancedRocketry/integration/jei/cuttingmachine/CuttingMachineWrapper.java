package zmaster587.advancedRocketry.integration.jei.cuttingmachine;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class CuttingMachineWrapper extends MachineRecipe {

	CuttingMachineWrapper(IRecipe rec) {
		super(rec);
	}

}

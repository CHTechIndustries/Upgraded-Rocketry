package zmaster587.advancedRocketry.block.cable;

public class BlockEnergyCable extends BlockPipe {

	public BlockEnergyCable(Properties material) {
		super(material);
	}
	
	/*@Override
	public TileEntity createTileEntity(World world, BlockState state) {
		return new TileEnergyPipe();
	}*/

}

package zmaster587.advancedRocketry.block.cable;

public class BlockDataCable extends BlockPipe {
	
	public BlockDataCable(Properties material) {
		super(material);
	}

	
	/*@Override
	public TileEntity createTileEntity(World world, BlockState state) {
		return new TileDataPipe();
	}*/

}

package zmaster587.advancedRocketry.block.cable;

public class BlockLiquidPipe extends BlockPipe {
	
	public BlockLiquidPipe(Properties material) {
		super(material);
	}

	
	
	/*@Override
	public TileEntity createTileEntity(World world, BlockState state) {
		return new TileLiquidPipe();
	}*/
}

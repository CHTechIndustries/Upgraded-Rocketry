package zmaster587.advancedRocketry.client.render.planet;

import com.mojang.blaze3d.matrix.MatrixStack;

public interface ISkyRenderer {
	public void render(MatrixStack matrix, float partialTicks);
}

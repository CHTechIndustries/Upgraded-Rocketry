package zmaster587.advancedRocketry.compat;

public class Compat {
	public static boolean isSpongeInstalled;
}

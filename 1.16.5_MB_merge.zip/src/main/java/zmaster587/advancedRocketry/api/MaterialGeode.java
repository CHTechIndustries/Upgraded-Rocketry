package zmaster587.advancedRocketry.api;

import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialColor;

public class MaterialGeode {

	public static final Material geode = new Material.Builder(MaterialColor.BLACK_TERRACOTTA).build();
}

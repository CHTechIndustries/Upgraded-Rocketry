---
name: Feature request
about: Suggest an idea for this project
title: "[Request]"
labels: enhancement
assignees: ''

---

**What do you think is missing or what do you think can be done better**
[Describe in detail what you want to see and how it makes the mod better]

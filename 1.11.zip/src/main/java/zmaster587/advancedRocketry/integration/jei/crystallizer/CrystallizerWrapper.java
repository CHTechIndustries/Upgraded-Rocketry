package zmaster587.advancedRocketry.integration.jei.crystallizer;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class CrystallizerWrapper extends MachineRecipe {

	CrystallizerWrapper(IRecipe rec) {
		super(rec);
	}

}

package zmaster587.advancedRocketry.integration.jei.sawmill;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class SawMillWrapper extends MachineRecipe {

	SawMillWrapper(IRecipe rec) {
		super(rec);
	}

}

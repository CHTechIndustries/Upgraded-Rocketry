---
name: Feature Request
about: Suggest an idea for feature for this mod
labels: enhancement
assignees: ''

---

**BEFORE making an issue**, consult [here](https://discord.com/channels/399708323126968321/803835260595994664/803841882086047754), [here](https://discord.com/channels/399708323126968321/803835260595994664/803845690652229693), and [here](https://discord.com/channels/399708323126968321/803835260595994664/803845709597638656) on the discord and make sure your suggestion is not something we are not going to make at this time, and make sure it has not already been suggested by checking the [closed issues](https://github.com/zmaster587/AdvancedRocketry/issues?q=is%3Aissue+is%3Aclosed)

**What do you think is missing or what do you think can be done better**
[Describe in detail what you want to see and how it makes the mod better]

package zmaster587.advancedRocketry.item;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;

public class ItemFluid extends ItemBlock {

	public ItemFluid(Block block) {
		super(block);
	}
	
}

package zmaster587.advancedRocketry.tile.multiblock.machine;

import zmaster587.libVulpes.interfaces.IRecipe;
import zmaster587.libVulpes.tile.multiblock.TileMultiblockMachine;

import java.util.List;

public class TileDistillationTower extends TileMultiblockMachine {

	@Override
	public List<IRecipe> getMachineRecipeList() {
		return null;
	}
}

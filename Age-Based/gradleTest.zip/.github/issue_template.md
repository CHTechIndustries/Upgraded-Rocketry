## Version of Advanced Rocketry
[insert here]
## Have you verified this is an issue in the latest unstable build
Y,N, N/A
## Version of LibVulpes
[insert here]
## Version of Minecraft
[insert here]
## Crash report or log (if applicable)
http://pastebin.com is a good place to put them
crash reports that are put in the issue itself are
hard to read
[insert here]

## Description of the problem
[How can you reliably reproduce the problem]
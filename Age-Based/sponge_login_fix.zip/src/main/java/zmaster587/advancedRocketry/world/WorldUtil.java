package zmaster587.advancedRocketry.world;

import net.minecraft.world.WorldProvider;

public class WorldUtil {
	public WorldProvider getProviderForName(String name) {
		return null;
	}
}

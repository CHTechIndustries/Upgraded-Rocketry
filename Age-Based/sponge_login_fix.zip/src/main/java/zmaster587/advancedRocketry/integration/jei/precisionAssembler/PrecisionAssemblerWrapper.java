package zmaster587.advancedRocketry.integration.jei.precisionAssembler;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class PrecisionAssemblerWrapper extends MachineRecipe {

	PrecisionAssemblerWrapper(IRecipe rec) {
		super(rec);
	}

}

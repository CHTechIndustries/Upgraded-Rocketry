package zmaster587.advancedRocketry.api;

import net.minecraft.block.state.IBlockState;

public interface IIntake {
	public int getIntakeAmt(IBlockState state);
}

package zmaster587.advancedRocketry.backwardCompat;

import java.io.IOException;

public class ModelFormatException extends Exception {

	public ModelFormatException(String string, IOException e) {
		// TODO Auto-generated constructor stub
	}

	public ModelFormatException(String format, NumberFormatException e) {
		// TODO Auto-generated constructor stub
	}

	public ModelFormatException(String string) {
		// TODO Auto-generated constructor stub
	}

}

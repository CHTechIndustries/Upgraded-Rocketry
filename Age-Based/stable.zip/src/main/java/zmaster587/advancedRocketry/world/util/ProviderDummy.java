package zmaster587.advancedRocketry.world.util;

import net.minecraft.world.WorldProvider;

public class ProviderDummy extends WorldProvider {

	@Override
	public String getDimensionName() {
		return null;
	}

}

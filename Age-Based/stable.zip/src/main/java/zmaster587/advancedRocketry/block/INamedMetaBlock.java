package zmaster587.advancedRocketry.block;

public interface INamedMetaBlock {
	public String getUnlocalizedName(int damage);
}

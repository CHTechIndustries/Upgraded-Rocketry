package zmaster587.advancedRocketry.util;

public interface IAdjBlockUpdate {
	/**
	 * Called when an adjacent block is updated
	 */
	public void onAdjacentBlockUpdated();
}

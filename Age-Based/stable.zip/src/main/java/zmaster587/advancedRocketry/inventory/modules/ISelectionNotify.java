package zmaster587.advancedRocketry.inventory.modules;

public interface ISelectionNotify {
	public void onSelected(Object sender);
	
	public void onSelectionConfirmed(Object sender);

	public void onSystemFocusChanged(Object sender);
}

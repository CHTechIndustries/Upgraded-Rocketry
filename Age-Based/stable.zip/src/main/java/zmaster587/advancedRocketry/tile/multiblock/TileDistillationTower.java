package zmaster587.advancedRocketry.tile.multiblock;

import java.util.List;
import java.util.Set;

import zmaster587.libVulpes.interfaces.IRecipe;

public class TileDistillationTower extends TileMultiblockMachine {

	@Override
	public List<IRecipe> getMachineRecipeList() {
		return null;
	}
}

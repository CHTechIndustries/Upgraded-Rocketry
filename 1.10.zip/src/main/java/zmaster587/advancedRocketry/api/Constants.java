package zmaster587.advancedRocketry.api;

public class Constants {
	public static final String modId = "advancedRocketry";
}

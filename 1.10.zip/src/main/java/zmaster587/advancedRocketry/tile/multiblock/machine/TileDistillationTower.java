package zmaster587.advancedRocketry.tile.multiblock.machine;

import java.util.List;
import java.util.Set;

import zmaster587.libVulpes.interfaces.IRecipe;
import zmaster587.libVulpes.tile.multiblock.TileMultiblockMachine;

public class TileDistillationTower extends TileMultiblockMachine {

	@Override
	public List<IRecipe> getMachineRecipeList() {
		return null;
	}
}

package zmaster587.advancedRocketry.api;

import net.minecraft.world.gen.trunkplacer.TrunkPlacerType;
import zmaster587.advancedRocketry.world.gen.WorldGenAlienTree;
import zmaster587.advancedRocketry.world.gen.WorldGenCharredTree;

public class AdvancedRocktryTrees {
	
	//public static TrunkPlacerType<WorldGenAlienTree> ALIEN_TREE;
	//public static TrunkPlacerType<WorldGenCharredTree> CHARRED_TREE;
}

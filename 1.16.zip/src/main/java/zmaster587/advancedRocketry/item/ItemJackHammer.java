package zmaster587.advancedRocketry.item;

import com.google.common.collect.Sets;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.material.Material;
import net.minecraft.item.IItemTier;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.tags.ItemTags;
import zmaster587.advancedRocketry.api.MaterialGeode;

import java.util.Set;

public class ItemJackHammer extends ToolItem {
	
	private static final Set items = Sets.newHashSet(new Block[] {Blocks.COBBLESTONE, Blocks.STONE_BRICK_SLAB, Blocks.STONE_SLAB, Blocks.STONE, Blocks.SANDSTONE, Blocks.MOSSY_COBBLESTONE, Blocks.IRON_ORE, Blocks.IRON_BLOCK, Blocks.COAL_ORE, Blocks.GOLD_BLOCK, Blocks.GOLD_BLOCK, Blocks.DIAMOND_ORE, Blocks.DIAMOND_BLOCK, Blocks.ICE, Blocks.NETHERRACK, Blocks.LAPIS_ORE, Blocks.LAPIS_BLOCK, Blocks.REDSTONE_ORE, Blocks.RAIL, Blocks.DETECTOR_RAIL, Blocks.ACTIVATOR_RAIL});
	
	public ItemJackHammer(IItemTier toolMaterial, Item.Properties properties) {
		super(1, 1, toolMaterial, items, properties);
		
	}
	
	@Override
	public boolean getIsRepairable(ItemStack stackMe, ItemStack stackItem) {
		return ItemTags.getCollection().getOwningTags(stackItem.getItem()).stream().anyMatch(value -> value.getPath().equals("stickTitanium"));
	}
	
    
	@Override
    public boolean canHarvestBlock(BlockState blockIn)
    {
            return true;
    }
}

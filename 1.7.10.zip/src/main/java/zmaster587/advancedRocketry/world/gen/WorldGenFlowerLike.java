package zmaster587.advancedRocketry.world.gen;

import net.minecraft.block.Block;
import net.minecraft.world.gen.feature.WorldGenFlowers;

public class WorldGenFlowerLike extends WorldGenFlowers {

	public WorldGenFlowerLike(Block p_i45452_1_) {
		super(p_i45452_1_);
	}

	@Override
	public void func_150550_a(Block p_150550_1_, int p_150550_2_) {
		//Stop changing my flowers Minecraft! >.<
	}
}

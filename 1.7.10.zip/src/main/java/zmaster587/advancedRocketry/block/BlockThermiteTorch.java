package zmaster587.advancedRocketry.block;

import net.minecraft.block.BlockTorch;

public class BlockThermiteTorch extends BlockTorch {

}

package zmaster587.advancedRocketry.api;

public interface IIntake {
	public int getIntakeAmt(int meta);
}

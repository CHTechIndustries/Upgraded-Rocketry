package zmaster587.advancedRocketry.api;

import net.minecraftforge.fluids.Fluid;

/**
 * Stores AdvancedRocketry Fluids
 *
 */
public class AdvancedRocketryFluids {
	public static Fluid fluidOxygen;
	public static Fluid fluidHydrogen;
	public static Fluid fluidRocketFuel;
	public static Fluid fluidNitrogen;
}

package zmaster587.advancedRocketry.integration.jei.electrolyser;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class ElectrolyzerWrapper extends MachineRecipe {

	ElectrolyzerWrapper(IRecipe rec) {
		super(rec);
	}

}
